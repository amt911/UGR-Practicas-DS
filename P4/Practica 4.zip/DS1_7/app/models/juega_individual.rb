class JuegaIndividual < ApplicationRecord
  belongs_to :usuario
end
