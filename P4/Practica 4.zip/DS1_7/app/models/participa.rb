class Participa < ApplicationRecord
  belongs_to :torneo
  belongs_to :usuario
end
