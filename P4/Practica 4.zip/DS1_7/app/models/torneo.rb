class Torneo < ApplicationRecord
end
