class Partida < ApplicationRecord
end
