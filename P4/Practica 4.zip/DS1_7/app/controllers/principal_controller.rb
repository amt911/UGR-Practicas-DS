class PrincipalController < ApplicationController
  def index
  end
end
