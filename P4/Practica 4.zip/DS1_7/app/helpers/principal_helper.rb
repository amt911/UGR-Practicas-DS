module PrincipalHelper
end
