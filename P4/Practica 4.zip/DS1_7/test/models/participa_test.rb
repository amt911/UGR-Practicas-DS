require "test_helper"

class ParticipaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
