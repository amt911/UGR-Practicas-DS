require "test_helper"

class PartidaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
