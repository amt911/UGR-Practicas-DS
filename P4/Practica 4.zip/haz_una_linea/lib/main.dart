import 'package:flutter/material.dart';
import 'package:haz_una_linea/pantallas/inicio.dart';

void main() {
  runApp(const MyApp());
}
