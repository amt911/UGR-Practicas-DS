// ignore_for_file: constant_identifier_names
enum Movimientos{IZQUIERDA, DERECHA, GIRAR_IZDA, GIRAR_DCHA, BAJAR}