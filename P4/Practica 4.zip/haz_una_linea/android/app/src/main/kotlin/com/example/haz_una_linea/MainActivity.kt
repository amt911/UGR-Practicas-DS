package com.example.haz_una_linea

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
